This project is featured by:

VCA algo in managers and Advidor (with dynamic configuration).
The network must contain at least two managers.
The hash fuction hashes the data, this is not very effective.