This project is featured by:

VCA algo in managers and Advidor (with dynamic configuration).
The network must contain at least two managers.
The hash fuction hashes the block (not the data), it works as follows: Hash(Previous_h, Data, Public_key).
A complete network, which contains 4 managers, 4 miners and 8 IoT_Devices.